/**
 * ATI Time Tracker — Google Apps Script backend
 * ------------------------------------------------------------
 * Paste this whole file into Extensions > Apps Script of a new
 * Google Sheet, run setup() once, then Deploy > New deployment >
 * Web app (Execute as: Me, Who has access: Anyone).
 * See SETUP.md for the full walkthrough.
 */

// ===== SHEETS STORE (Apps Script only) =====
const Store = (function () {
  const cache = {};
  function sheet(name) {
    const sh = SpreadsheetApp.getActive().getSheetByName(name);
    if (!sh) throw new Error('Missing sheet "' + name + '". Run setup() first.');
    return sh;
  }
  function all(name) {
    if (cache[name]) return cache[name];
    const sh = sheet(name);
    const vals = sh.getDataRange().getDisplayValues();
    const head = vals.shift() || [];
    const rows = vals
      .filter(r => r.some(c => c !== ''))
      .map(r => { const o = {}; head.forEach((h, i) => { if (h) o[h] = r[i]; }); return o; });
    cache[name] = rows;
    return rows;
  }
  function headers(name) {
    const sh = sheet(name);
    return sh.getRange(1, 1, 1, sh.getLastColumn()).getDisplayValues()[0];
  }
  function toRow(head, o) {
    return head.map(h => (o[h] === undefined || o[h] === null) ? '' : o[h]);
  }
  function upsertMany(name, key, objs) {
    if (!objs.length) return;
    const sh = sheet(name);
    const head = headers(name);
    const kIdx = head.indexOf(key);
    const last = sh.getLastRow();
    const keys = last > 1 ? sh.getRange(2, kIdx + 1, last - 1, 1).getDisplayValues().map(r => r[0]) : [];
    const appends = [];
    // force text format (keeps PIN leading zeros, dates as YYYY-MM-DD) except Hours
    const fmt = n => Array.from({ length: n }, () => head.map(h => h === 'Hours' ? '0.00' : '@'));
    objs.forEach(o => {
      const i = keys.indexOf(String(o[key]));
      if (i >= 0) sh.getRange(i + 2, 1, 1, head.length).setNumberFormats(fmt(1)).setValues([toRow(head, o)]);
      else appends.push(toRow(head, o));
    });
    if (appends.length) sh.getRange(sh.getLastRow() + 1, 1, appends.length, head.length).setNumberFormats(fmt(appends.length)).setValues(appends);
    delete cache[name];
  }
  function remove(name, key, keyVals) {
    const sh = sheet(name);
    const head = headers(name);
    const kIdx = head.indexOf(key);
    const last = sh.getLastRow();
    if (last < 2) return;
    const keys = sh.getRange(2, kIdx + 1, last - 1, 1).getDisplayValues().map(r => r[0]);
    const want = keyVals.map(String);
    for (let i = keys.length - 1; i >= 0; i--) if (want.indexOf(keys[i]) >= 0) sh.deleteRow(i + 2);
    delete cache[name];
  }
  return { all, upsertMany, remove };
})();

// short-lived counters for lockouts
const Cache = {
  get: k => CacheService.getScriptCache().get(k),
  put: (k, v, secs) => CacheService.getScriptCache().put(k, String(v), secs),
  remove: k => CacheService.getScriptCache().remove(k)
};

// signing secret for session tokens (kept in Script Properties, never in the Sheet)
const Env = {
  secret() {
    const pr = PropertiesService.getScriptProperties();
    let k = pr.getProperty('TOKEN_SECRET');
    if (!k) { k = Utilities.getUuid() + Utilities.getUuid(); pr.setProperty('TOKEN_SECRET', k); }
    return k;
  },
  rotate() { PropertiesService.getScriptProperties().setProperty('TOKEN_SECRET', Utilities.getUuid() + Utilities.getUuid()); }
};

function nowStamp() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
}

// ===== HTTP ENTRY POINTS (Apps Script only) =====
function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'ping';
  return respond(() => api(action, e.parameter || {}));
}

function doPost(e) {
  const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  const lock = LockService.getScriptLock();
  return respond(() => {
    lock.waitLock(25000);
    try { return api(body.action, body); } finally { lock.releaseLock(); }
  });
}

function respond(fn) {
  let out;
  try { out = fn(); } catch (err) { out = { error: String(err && err.message || err) }; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

// ===== ONE-TIME SETUP (Apps Script only) =====
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Time Tracker').addItem('Run setup / repair', 'setup').addToUi();
}

function setup() {
  const ss = SpreadsheetApp.getActive();
  Object.keys(SHEETS).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const head = SHEETS[name];
    sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#1d2433').setFontColor('#ffffff');
    sh.setFrozenRows(1);
    // keep IDs, dates, times, PINs as plain text so Sheets doesn't "helpfully" convert them
    head.forEach((h, i) => {
      if (h !== 'Hours') sh.getRange(2, i + 1, sh.getMaxRows() - 1, 1).setNumberFormat('@');
    });
  });
  const set = ss.getSheetByName('Settings');
  const have = set.getLastRow() > 1 ? set.getRange(2, 1, set.getLastRow() - 1, 1).getValues().map(r => r[0]) : [];
  const add = DEFAULT_SETTINGS.filter(r => have.indexOf(r[0]) < 0);
  if (add.length) set.getRange(set.getLastRow() + 1, 1, add.length, 3).setValues(add);
  const emp = ss.getSheetByName('Employees');
  if (emp.getLastRow() < 2) emp.getRange(2, 1, 1, 6).setValues([['E001', 'Test Tech', '1234', 'TRUE', 'Tech, Test', 'Delete me once real techs are added']]);
  const jobs = ss.getSheetByName('Jobs');
  if (jobs.getLastRow() < 2) jobs.getRange(2, 1, 1, 8).setValues([['SHOP', 'ATI', '', '', 'Shop / warehouse / office (non-billable)', 'Active', '', nowStamp()]]);
  const s1 = ss.getSheetByName('Sheet1');
  if (s1 && s1.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(s1);
  try { SpreadsheetApp.getUi().alert('Setup complete. Change AdminPassword on the Settings tab (it is only used to sign in the first time and create office users), then deploy as a Web app.'); } catch (e) {}
}

// ===== API LOGIC (shared with demo-backend.js — keep in sync via build.js) =====
// @@LOGIC_START
const SHEETS = {
  Employees: ['EmpID', 'Name', 'PIN', 'Active', 'PayrollName', 'Notes'],
  Jobs: ['JobNo', 'Customer', 'PO', 'Quote', 'Description', 'Status', 'RequestedBy', 'CreatedAt', 'QBJob', 'CustomerName'],
  Entries: ['EntryID', 'EmpID', 'Employee', 'Date', 'Type', 'JobNo', 'Start', 'End', 'Hours', 'Notes', 'Status', 'OfficeNote', 'UpdatedAt', 'UpdatedBy', 'QBExported', 'LunchMin'],
  Settings: ['Key', 'Value', 'Help'],
  OfficeUsers: ['Name', 'PassHash', 'Active', 'CreatedAt', 'LastLogin']
};

const DEFAULT_SETTINGS = [
  ['AdminPassword', 'change-me', 'SETUP password — only works until the first office user is created. CHANGE THIS.'],
  ['CompanyName', 'Academic Technologies Inc', 'Shown on reports and printouts'],
  ['WeekStart', '0', 'First day of the FLSA workweek: 0=Sunday, 1=Monday ... 6=Saturday'],
  ['OTThreshold', '40', 'Weekly paid hours before overtime'],
  ['TravelPaid', 'TRUE', 'TRUE = travel counts as paid hours (and toward OT)'],
  ['PayPeriod', 'biweekly', 'weekly or biweekly'],
  ['PayPeriodAnchor', '2026-01-04', 'The first day of ANY past pay period (YYYY-MM-DD) — must fall on WeekStart'],
  ['JobSeparator', '-', 'Character between the PO and Quote # in job numbers (customer + PO are run together, e.g. GHS45021-Q1187)'],
  ['DefaultLunchMinutes', '60', 'Lunch pre-filled on each day card, in minutes (techs can change it)'],
  ['QuietDays', '30', 'Active jobs with no time posted in this many days show on the "Gone quiet" list'],
  ['OfficeIdleMinutes', '30', 'Office dashboard signs out after this many idle minutes (5–480)'],
  ['TechSessionDays', '30', 'Techs re-enter their PIN after this many days (0 = never)'],
  ['QBCompanyName', '', 'QuickBooks Desktop: company name exactly as in the TIMERHDR line of an exported Timer List'],
  ['QBCompanyCreateTime', '', 'QuickBooks Desktop: COMPANYCREATETIME number from File > Utilities > Export > Timer Lists'],
  ['QBTimerVer', '7', 'QuickBooks Desktop: VER from the exported Timer List'],
  ['QBTimerRel', '0', 'QuickBooks Desktop: REL from the exported Timer List'],
  ['QBItemLabor', 'Labor', 'Service item for job time'],
  ['QBItemTravel', 'Travel', 'Service item for travel time'],
  ['QBItemShop', 'Shop', 'Service item for shop/office time (blank = none)'],
  ['QBShopJob', '', 'Customer:Job for shop time (blank = no customer)'],
  ['QBPayRegular', 'Hourly Rate', 'Payroll item for regular hours — must match QuickBooks exactly'],
  ['QBPayOT', 'Overtime Rate', 'Payroll item for overtime hours'],
  ['QBPayPTO', 'Vacation Hourly', 'Payroll item for PTO hours'],
  ['QBPayHoliday', 'Holiday Hourly', 'Payroll item for holiday hours'],
  ['QBTravelBillable', 'FALSE', 'TRUE = travel lines marked billable to the customer']
];

// 'Day' = the tech's day card (In/Out/Lunch). 'Break' is the older lunch line, still accepted.
const ENTRY_TYPES = ['Job', 'Travel', 'Shop', 'Break', 'PTO', 'Holiday', 'Day'];
const STATUSES = ['Open', 'Submitted', 'Approved'];

function api(action, p) {
  NEW_TOKEN = null;
  const out = apiInner(action, p || {});
  if (NEW_TOKEN && out && typeof out === 'object') out.token = NEW_TOKEN;
  return out;
}

function apiInner(action, p) {
  switch (action) {
    case 'ping': return { ok: true, version: 1 };
    case 'names': return { names: employees().filter(isActive).map(e => ({ id: e.EmpID, name: e.Name })) };

    // ---------- technician ----------
    case 'login': {
      const e = authTech(p);
      return { emp: pubEmp(e), jobs: jobsFor(e), customers: customerList(), settings: pubSettings(), token: techToken(e) };
    }
    case 'jobs': {
      const e = authTech(p);
      return { jobs: jobsFor(e), customers: customerList(), settings: pubSettings() };
    }
    case 'entries': {
      const e = authTech(p);
      return { entries: entriesIn(p.from, p.to).filter(r => String(r.EmpID) === String(e.EmpID)) };
    }
    case 'sync': {
      const e = authTech(p);
      return { results: techSync(e, p.ops || []) };
    }
    case 'submit': {
      const e = authTech(p);
      const rows = rawEntries().filter(r => String(r.EmpID) === String(e.EmpID) && r.Date >= p.from && r.Date <= p.to && (r.Status || 'Open') === 'Open');
      rows.forEach(r => { r.Status = 'Submitted'; r.UpdatedAt = nowStamp(); r.UpdatedBy = e.Name; });
      Store.upsertMany('Entries', 'EntryID', rows);
      return { submitted: rows.length, entries: entriesIn(p.from, p.to).filter(r => String(r.EmpID) === String(e.EmpID)) };
    }
    case 'requestJob': {
      const e = authTech(p);
      const job = makeJob(p, 'Pending', e.Name);
      return { job: job, jobs: jobsFor(e), customers: customerList() };
    }

    // ---------- office ----------
    case 'adminLogin': {
      const a = authAdmin(p);
      if (a.user) Store.upsertMany('OfficeUsers', 'Name', [Object.assign({}, a.user, { LastLogin: nowStamp() })]);
      return { ok: true, user: ACTOR, bootstrap: !!a.bootstrap, settings: adminSettings() };
    }
    case 'adminPing': {
      authAdmin(p);
      return { ok: true };
    }
    case 'adminLoad': {
      const a = authAdmin(p);
      return { employees: employees().map(adminEmp), jobs: Store.all('Jobs'), entries: entriesIn(p.from, p.to), activity: jobActivity(), settings: adminSettings(), users: officeUsers(), user: ACTOR, bootstrap: !!a.bootstrap };
    }
    case 'adminSaveUser': {
      const a = authAdmin(p);
      const x = p.officeUser || {};
      const name = String(x.Name || '').trim();
      if (!name) throw new Error('Name is required');
      const list = Store.all('OfficeUsers').filter(u => u.Name);
      const old = list.filter(u => u.Name.toLowerCase() === name.toLowerCase())[0];
      if (x.isNew && old) throw new Error('There is already an office user named ' + old.Name);
      if (!x.isNew && !old) throw new Error('Unknown office user');
      if ((x.isNew || x.Password) && String(x.Password || '').length < 8) throw new Error('Password must be at least 8 characters');
      const active = x.Active === false || x.Active === 'FALSE' ? 'FALSE' : 'TRUE';
      if (active === 'FALSE' && !list.some(u => isActive(u) && u.Name.toLowerCase() !== name.toLowerCase())) throw new Error('You need at least one active office user');
      if (active === 'FALSE' && old && old.Name === ACTOR) throw new Error("You can't deactivate yourself");
      const row = {
        Name: old ? old.Name : name,
        PassHash: x.Password ? hashPass(old ? old.Name : name, x.Password) : old.PassHash,
        Active: active,
        CreatedAt: old ? old.CreatedAt : nowStamp(),
        LastLogin: old ? old.LastLogin : ''
      };
      Store.upsertMany('OfficeUsers', 'Name', [row]);
      clearFail('admin:' + row.Name.toLowerCase());
      if (row.Name === ACTOR) NEW_TOKEN = adminToken(row);
      return { users: officeUsers(), bootstrapOver: !!a.bootstrap };
    }
    case 'adminChangePassword': {
      const a = authAdmin(p);
      if (!a.user) throw new Error('Create your office user first (Employees tab), then sign in with it');
      if (String(p.newPassword || '').length < 8) throw new Error('Password must be at least 8 characters');
      const upd = Object.assign({}, a.user, { PassHash: hashPass(a.user.Name, p.newPassword) });
      Store.upsertMany('OfficeUsers', 'Name', [upd]);
      NEW_TOKEN = adminToken(upd);
      return { ok: true };
    }
    case 'adminSaveEntries': {
      authAdmin(p);
      const existing = indexBy(rawEntries(), 'EntryID');
      const emps = indexBy(employees(), 'EmpID');
      const rows = (p.entries || []).map(x => {
        const old = existing[x.EntryID] || {};
        const r = normalizeEntry(Object.assign({}, old, x));
        const emp = emps[r.EmpID];
        if (!emp) throw new Error('Unknown employee ' + r.EmpID);
        r.Employee = emp.Name;
        r.Status = x.Status || old.Status || 'Open';
        r.QBExported = qbStamp(old, r);
        r.UpdatedAt = nowStamp();
        r.UpdatedBy = ACTOR;
        return r;
      });
      Store.upsertMany('Entries', 'EntryID', rows);
      return { entries: rows.map(cleanEntry) };
    }
    case 'adminDeleteEntries': {
      authAdmin(p);
      Store.remove('Entries', 'EntryID', p.ids || []);
      return { deleted: (p.ids || []).length };
    }
    case 'adminSetStatus': {
      authAdmin(p);
      if (STATUSES.indexOf(p.status) < 0) throw new Error('Bad status');
      const want = {}; (p.ids || []).forEach(id => { want[id] = true; });
      const rows = rawEntries().filter(r => want[r.EntryID]);
      rows.forEach(r => {
        r.Status = p.status;
        if (p.note !== undefined) r.OfficeNote = p.note;
        r.UpdatedAt = nowStamp();
        r.UpdatedBy = ACTOR;
      });
      Store.upsertMany('Entries', 'EntryID', rows);
      return { updated: rows.length, entries: rows.map(cleanEntry) };
    }
    case 'adminSaveEmployee': {
      authAdmin(p);
      const x = p.employee || {};
      const name = String(x.Name || '').trim();
      if (!name) throw new Error('Name is required');
      const list = employees();
      const oldEmp = list.filter(e => x.EmpID && e.EmpID === x.EmpID)[0];
      const newPin = String(x.PIN || '').trim();
      if (newPin && !/^\d{4,6}$/.test(newPin)) throw new Error('PIN must be 4–6 digits');
      if (!oldEmp && !newPin) throw new Error('A PIN is required for a new employee');
      if (list.some(e => e.Name.toLowerCase() === name.toLowerCase() && e.EmpID !== x.EmpID)) throw new Error('Another employee already has that name');
      let id = x.EmpID;
      if (!id) {
        const max = list.reduce((m, e) => Math.max(m, parseInt(String(e.EmpID).replace(/\D/g, ''), 10) || 0), 0);
        id = 'E' + String(max + 1).padStart(3, '0');
      }
      const row = { EmpID: id, Name: name, PIN: newPin ? hashPin(id, newPin) : oldEmp.PIN, Active: x.Active === false || x.Active === 'FALSE' ? 'FALSE' : 'TRUE', PayrollName: x.PayrollName || name, Notes: x.Notes || '' };
      Store.upsertMany('Employees', 'EmpID', [row]);
      if (newPin) clearFail('emp:' + id);
      return { employee: adminEmp(row), employees: employees().map(adminEmp) };
    }
    case 'adminSaveJob': {
      authAdmin(p);
      const x = p.job || {};
      const oldNo = p.oldJobNo;
      const newNo = String(x.JobNo || '').trim().toUpperCase();
      if (!newNo) throw new Error('Job number is required');
      const jobs = Store.all('Jobs');
      const clash = jobs.filter(j => j.JobNo === newNo)[0];
      let merged = 0;
      if (oldNo && oldNo !== newNo) {
        // rename or merge: move all time from the old job number to the new one
        const rows = rawEntries().filter(r => r.JobNo === oldNo);
        rows.forEach(r => { r.JobNo = newNo; r.UpdatedAt = nowStamp(); r.UpdatedBy = ACTOR; });
        Store.upsertMany('Entries', 'EntryID', rows);
        merged = rows.length;
        Store.remove('Jobs', 'JobNo', [oldNo]);
      }
      const base = clash || {};
      const row = {
        JobNo: newNo,
        Customer: x.Customer !== undefined ? x.Customer : (base.Customer || ''),
        PO: x.PO !== undefined ? x.PO : (base.PO || ''),
        Quote: x.Quote !== undefined ? x.Quote : (base.Quote || ''),
        Description: x.Description !== undefined ? x.Description : (base.Description || ''),
        Status: x.Status || base.Status || 'Active',
        RequestedBy: base.RequestedBy || x.RequestedBy || '',
        CreatedAt: base.CreatedAt || x.CreatedAt || nowStamp(),
        QBJob: x.QBJob !== undefined ? x.QBJob : (base.QBJob || ''),
        CustomerName: x.CustomerName !== undefined ? x.CustomerName : (base.CustomerName || '')
      };
      // keep one full name per customer abbreviation across all jobs
      if (row.Customer && row.CustomerName) {
        const same = Store.all('Jobs').filter(j => j.Customer === row.Customer && j.JobNo !== row.JobNo && j.CustomerName !== row.CustomerName);
        same.forEach(j => { j.CustomerName = row.CustomerName; });
        Store.upsertMany('Jobs', 'JobNo', same);
      }
      Store.upsertMany('Jobs', 'JobNo', [row]);
      return { job: row, movedEntries: merged, jobs: Store.all('Jobs') };
    }
    case 'adminSetJobStatus': {
      authAdmin(p);
      const want = {}; (p.jobNos || []).forEach(n => { want[n] = true; });
      const st = p.status === 'Active' ? 'Active' : 'Closed';
      const rows = Store.all('Jobs').filter(j => want[j.JobNo]);
      rows.forEach(j => { j.Status = st; });
      Store.upsertMany('Jobs', 'JobNo', rows);
      return { updated: rows.length, jobs: Store.all('Jobs') };
    }
    case 'adminDeleteJob': {
      authAdmin(p);
      const used = rawEntries().some(r => r.JobNo === p.jobNo);
      if (used) throw new Error('That job has time posted to it. Set it to Closed instead, or merge it into another job.');
      Store.remove('Jobs', 'JobNo', [p.jobNo]);
      return { jobs: Store.all('Jobs') };
    }
    case 'adminRevokeAll': {
      const a = authAdmin(p);
      Env.rotate();
      NEW_TOKEN = a.user ? adminToken(a.user) : adminToken(null, ACTOR.replace(/ \(setup\)$/, ''));
      return { ok: true };
    }
    case 'adminSaveSettings': {
      authAdmin(p);
      const allowed = {}; DEFAULT_SETTINGS.forEach(r => { allowed[r[0]] = r[2]; });
      const v = p.values || {};
      if (v.DefaultLunchMinutes !== undefined) v.DefaultLunchMinutes = String(Math.max(0, Math.min(240, parseInt(v.DefaultLunchMinutes, 10) || 0)));
      if (v.QuietDays !== undefined) v.QuietDays = String(Math.max(1, Math.min(365, parseInt(v.QuietDays, 10) || 30)));
      if (v.OfficeIdleMinutes !== undefined) v.OfficeIdleMinutes = String(Math.max(5, Math.min(480, parseInt(v.OfficeIdleMinutes, 10) || 30)));
      if (v.TechSessionDays !== undefined) v.TechSessionDays = String(Math.max(0, Math.min(365, parseInt(v.TechSessionDays, 10) || 0)));
      const cur = indexBy(Store.all('Settings'), 'Key');
      const rows = Object.keys(p.values || {}).filter(k => k !== 'AdminPassword' && allowed[k] !== undefined)
        .map(k => ({ Key: k, Value: String(p.values[k]), Help: (cur[k] && cur[k].Help) || allowed[k] }));
      Store.upsertMany('Settings', 'Key', rows);
      return { settings: adminSettings() };
    }
    case 'adminMarkExported': {
      authAdmin(p);
      const want = {}; (p.ids || []).forEach(id => { want[id] = true; });
      const stamp = p.clear ? '' : nowStamp();
      const rows = rawEntries().filter(r => want[r.EntryID]);
      rows.forEach(r => { r.QBExported = stamp; });
      Store.upsertMany('Entries', 'EntryID', rows);
      return { updated: rows.length, stamp: stamp };
    }
    default:
      throw new Error('Unknown action: ' + action);
  }
}

// ---------- helpers ----------
function settingsMap() {
  const m = {};
  DEFAULT_SETTINGS.forEach(r => { m[r[0]] = r[1]; });
  Store.all('Settings').forEach(r => { if (r.Key) m[r.Key] = r.Value; });
  return m;
}
function pubSettings() {
  const s = settingsMap();
  return {
    CompanyName: s.CompanyName,
    WeekStart: parseInt(s.WeekStart, 10) || 0,
    OTThreshold: parseFloat(s.OTThreshold) || 40,
    TravelPaid: String(s.TravelPaid).toUpperCase() !== 'FALSE',
    PayPeriod: String(s.PayPeriod || 'biweekly').toLowerCase(),
    PayPeriodAnchor: s.PayPeriodAnchor,
    JobSeparator: s.JobSeparator === undefined ? '-' : s.JobSeparator,
    DefaultLunchMinutes: (function (v) { v = parseInt(v, 10); return isNaN(v) ? 60 : Math.max(0, Math.min(240, v)); })(s.DefaultLunchMinutes)
  };
}
function adminSettings() {
  const s = settingsMap();
  const o = pubSettings();
  DEFAULT_SETTINGS.forEach(r => { if (r[0].indexOf('QB') === 0) o[r[0]] = s[r[0]]; });
  o.OfficeIdleMinutes = idleMinutes();
  o.QuietDays = Math.max(1, Math.min(365, parseInt(s.QuietDays, 10) || 30));
  o.TechSessionDays = techDays();
  o.QBTravelBillable = String(s.QBTravelBillable).toUpperCase() === 'TRUE';
  return o;
}
function employees() { return Store.all('Employees').filter(e => e.EmpID); }
function isActive(e) { return String(e.Active).toUpperCase() !== 'FALSE'; }
function pubEmp(e) { return { id: e.EmpID, name: e.Name }; }
function indexBy(list, k) { const o = {}; list.forEach(x => { o[x[k]] = x; }); return o; }

// ---------- security ----------
let ACTOR = 'Office';
let NEW_TOKEN = null;

function idleMinutes() { return Math.max(5, Math.min(480, parseInt(settingsMap().OfficeIdleMinutes, 10) || 30)); }
function techDays() { const d = parseInt(settingsMap().TechSessionDays, 10); return isNaN(d) ? 30 : Math.max(0, Math.min(365, d)); }
function sign(payload) { const k = Env.secret(); return sha256(k + ':' + sha256(k + ':' + payload)); }
function makeToken(o) { const pl = encodeURIComponent(JSON.stringify(o)); return pl + '.' + sign(pl); }
function readToken(tok) {
  tok = String(tok || ''); const i = tok.lastIndexOf('.');
  if (i < 0) return null;
  const pl = tok.slice(0, i);
  if (sign(pl) !== tok.slice(i + 1)) return null;
  try { const o = JSON.parse(decodeURIComponent(pl)); return o.exp < Date.now() ? { expired: true, k: o.k } : o; } catch (e) { return null; }
}
const credTag = h => String(h || '').slice(-12);
function techToken(e) {
  const d = techDays();
  return makeToken({ k: 't', id: e.EmpID, c: credTag(e.PIN), exp: Date.now() + (d > 0 ? d : 3650) * 864e5 });
}
function adminToken(u, setupName) {
  return makeToken({ k: 'a', u: u ? u.Name : setupName, c: u ? credTag(u.PassHash) : 'setup', exp: Date.now() + idleMinutes() * 60000 });
}
const MAX_TRIES = 5, LOCK_SECS = 900;

function checkLock(key, max) {
  const n = parseInt(Cache.get('fail:' + key) || '0', 10);
  if (n >= (max || MAX_TRIES)) throw new Error('AUTH: Too many wrong tries. Locked for 15 minutes' + (key.indexOf('emp:') === 0 ? ' — or ask the office to reset your PIN.' : '.'));
}
function noteFail(key) {
  const n = parseInt(Cache.get('fail:' + key) || '0', 10) + 1;
  Cache.put('fail:' + key, n, LOCK_SECS);
}
function clearFail(key) { Cache.remove('fail:' + key); }

function hashPin(empId, pin) { return 'h1$' + sha256('pin:' + empId + ':' + pin); }
function hashPass(name, pw) {
  let h = 'pw:' + String(name).toLowerCase() + ':' + pw;
  for (let i = 0; i < 300; i++) h = sha256(h);
  return 'h1$' + h;
}
function adminEmp(e) {
  const o = Object.assign({}, e);
  o.PINSet = !!e.PIN; delete o.PIN;
  return o;
}
function officeUsers() {
  return Store.all('OfficeUsers').filter(u => u.Name).map(u => ({ Name: u.Name, Active: u.Active, CreatedAt: u.CreatedAt, LastLogin: u.LastLogin }));
}

function authTech(p) {
  if (p.token) {
    const o = readToken(p.token);
    if (o && o.expired) throw new Error('AUTH: Your sign-in expired. Enter your PIN to continue.');
    const e = o && o.k === 't' && employees().filter(x => String(x.EmpID) === String(o.id))[0];
    if (!e || !isActive(e) || credTag(e.PIN) !== o.c) throw new Error('AUTH: Please sign in again');
    return e;
  }
  const e = employees().filter(x => String(x.EmpID) === String(p.empId))[0];
  if (!e || !isActive(e)) throw new Error('AUTH: Name or PIN not recognized');
  const key = 'emp:' + e.EmpID;
  checkLock(key);
  const stored = String(e.PIN || '');
  const pin = String(p.pin || '');
  let ok = false;
  if (/^\d{4,6}$/.test(stored)) {
    // PIN typed straight into the sheet: accept it once, then store it hashed
    ok = stored === pin;
    if (ok) { const upd = Object.assign({}, e, { PIN: hashPin(e.EmpID, pin) }); Store.upsertMany('Employees', 'EmpID', [upd]); clearFail(key); return upd; }
  } else ok = !!stored && stored === hashPin(e.EmpID, pin);
  if (!ok) { noteFail(key); throw new Error('AUTH: Name or PIN not recognized'); }
  clearFail(key);
  return e;
}

function authAdmin(p) {
  if (p.token) {
    const o = readToken(p.token);
    if (o && o.expired) throw new Error('AUTH: Signed out after ' + idleMinutes() + ' minutes of no activity');
    if (!o || o.k !== 'a') throw new Error('AUTH: Please sign in again');
    const users = Store.all('OfficeUsers').filter(u => u.Name);
    if (o.c === 'setup') {
      if (users.length) throw new Error('AUTH: Setup sign-in is no longer allowed. Sign in with your office user.');
      ACTOR = o.u + ' (setup)'; NEW_TOKEN = adminToken(null, o.u);
      return { bootstrap: true };
    }
    const u = users.filter(x => x.Name === o.u)[0];
    if (!u || !isActive(u) || credTag(u.PassHash) !== o.c) throw new Error('AUTH: Please sign in again');
    ACTOR = u.Name; NEW_TOKEN = adminToken(u);
    return { user: u };
  }
  const name = String(p.user || '').trim();
  const key = 'admin:' + name.toLowerCase();
  checkLock('admin:*', 25);
  checkLock(key);
  const users = Store.all('OfficeUsers').filter(u => u.Name);
  if (!users.length) {
    // first-time setup: the AdminPassword setting works until an office user exists
    const s = settingsMap();
    if (p.password && s.AdminPassword && String(p.password) === String(s.AdminPassword)) {
      clearFail(key);
      ACTOR = (name || 'Office') + ' (setup)';
      NEW_TOKEN = adminToken(null, name || 'Office');
      return { bootstrap: true };
    }
  } else {
    const u = users.filter(x => x.Name.toLowerCase() === name.toLowerCase())[0];
    if (u && isActive(u) && p.password && hashPass(u.Name, p.password) === u.PassHash) {
      clearFail(key);
      ACTOR = u.Name;
      NEW_TOKEN = adminToken(u);
      return { user: u };
    }
  }
  noteFail(key); noteFail('admin:*');
  throw new Error('AUTH: Wrong name or password');
}

// compact SHA-256 (UTF-8 string -> hex); identical in Apps Script and the browser demo
function sha256(str) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const bytes = [];
  const u = unescape(encodeURIComponent(String(str)));
  for (let i = 0; i < u.length; i++) bytes.push(u.charCodeAt(i));
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? 0 : (bitLen >>> (i * 8)) & 0xff);
  let H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const W = new Array(64);
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  for (let off = 0; off < bytes.length; off += 64) {
    for (let t = 0; t < 16; t++) W[t] = (bytes[off + t * 4] << 24) | (bytes[off + t * 4 + 1] << 16) | (bytes[off + t * 4 + 2] << 8) | bytes[off + t * 4 + 3];
    for (let t = 16; t < 64; t++) {
      const s0 = rotr(W[t - 15], 7) ^ rotr(W[t - 15], 18) ^ (W[t - 15] >>> 3);
      const s1 = rotr(W[t - 2], 17) ^ rotr(W[t - 2], 19) ^ (W[t - 2] >>> 10);
      W[t] = (W[t - 16] + s0 + W[t - 7] + s1) | 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let t = 0; t < 64; t++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[t] + W[t]) | 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const mj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + mj) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H = [(H[0] + a) | 0, (H[1] + b) | 0, (H[2] + c) | 0, (H[3] + d) | 0, (H[4] + e) | 0, (H[5] + f) | 0, (H[6] + g) | 0, (H[7] + h) | 0];
  }
  return H.map(x => ('00000000' + (x >>> 0).toString(16)).slice(-8)).join('');
}

function jobsFor(e) {
  return Store.all('Jobs')
    .filter(j => j.JobNo && (j.Status === 'Active' || j.Status === '' || (j.Status === 'Pending' && j.RequestedBy === e.Name)))
    .map(j => ({ JobNo: j.JobNo, Customer: j.Customer, CustomerName: j.CustomerName || '', Description: j.Description, Status: j.Status || 'Active' }));
}

/** Every customer abbreviation and its full name, from all jobs (open and closed). */
function customerList() {
  const m = {};
  Store.all('Jobs').forEach(j => {
    const a = String(j.Customer || '').trim().toUpperCase();
    if (!a) return;
    if (!m[a] || (!m[a].name && j.CustomerName)) m[a] = { abbr: a, name: j.CustomerName || '' };
  });
  return Object.keys(m).sort().map(k => m[k]);
}

/** Last date time was posted and total hours, per job (all time). */
function jobActivity() {
  const m = {};
  rawEntries().forEach(r => {
    if (!r.JobNo) return;
    const a = m[r.JobNo] || (m[r.JobNo] = { last: '', hours: 0 });
    if (r.Date > a.last) a.last = r.Date;
    a.hours += parseFloat(r.Hours) || 0;
  });
  Object.keys(m).forEach(k => { m[k].hours = Math.round(m[k].hours * 100) / 100; });
  return m;
}

function makeJob(p, status, who) {
  const s = pubSettings();
  const cust = String(p.customer || '').trim().toUpperCase();
  const po = String(p.po || '').trim();
  const quote = String(p.quote || '').trim();
  let no = String(p.jobNo || '').trim().toUpperCase();
  if (!no) no = (cust + po) && quote ? cust + po + s.JobSeparator + quote : (cust + po) || quote;
  if (!no) throw new Error('Enter at least a customer abbreviation and PO or quote number');
  const existing = Store.all('Jobs').filter(j => j.JobNo === no)[0];
  if (existing) return existing;
  let cname = String(p.customerName || '').trim();
  if (!cname && cust) { const known = customerList().filter(c => c.abbr === cust)[0]; if (known) cname = known.name; }
  const row = { JobNo: no, Customer: cust, CustomerName: cname, PO: po, Quote: quote, Description: String(p.description || '').trim(), Status: status, RequestedBy: who, CreatedAt: nowStamp() };
  Store.upsertMany('Jobs', 'JobNo', [row]);
  return row;
}

function rawEntries() { return Store.all('Entries').filter(r => r.EntryID); }
function entriesIn(from, to) {
  return rawEntries().filter(r => (!from || r.Date >= from) && (!to || r.Date <= to)).map(cleanEntry);
}
function cleanEntry(r) {
  const o = {};
  SHEETS.Entries.forEach(h => { o[h] = r[h] === undefined ? '' : r[h]; });
  o.Hours = Math.round((parseFloat(o.Hours) || 0) * 100) / 100;
  o.Status = o.Status || 'Open';
  o.LunchMin = parseInt(o.LunchMin, 10) || 0;
  return o;
}

// If time already sent to QuickBooks is changed, keep the stamp but mark it so the office knows to fix QuickBooks too
function qbStamp(old, r) {
  const st = String(old.QBExported || '');
  if (!st || st.indexOf('EDITED') === 0) return st;
  const same = ['EmpID', 'Date', 'Type', 'JobNo'].every(k => String(old[k] || '') === String(r[k] || '')) && Math.abs((parseFloat(old.Hours) || 0) - (parseFloat(r.Hours) || 0)) < 0.001;
  return same ? st : 'EDITED AFTER ' + st;
}

function hhmmToMin(t) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(t || ''));
  return m ? parseInt(m[1], 10) * 60 + parseInt(m[2], 10) : null;
}

function normalizeEntry(x) {
  const r = {};
  SHEETS.Entries.forEach(h => { r[h] = x[h] === undefined || x[h] === null ? '' : x[h]; });
  r.EntryID = String(r.EntryID || '').trim();
  if (!r.EntryID) throw new Error('Missing EntryID');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(r.Date)) throw new Error('Bad date');
  if (ENTRY_TYPES.indexOf(r.Type) < 0) throw new Error('Bad entry type');
  r.JobNo = String(r.JobNo || '').trim().toUpperCase();
  if (r.Type === 'Job' && !r.JobNo) throw new Error('Job number is required');
  if (r.Type === 'Day') {
    // day card: paid = (Out - In) - lunch. Out can be blank while the day is still going.
    const i = hhmmToMin(r.Start), o = hhmmToMin(r.End);
    if (i === null) throw new Error('Enter the In time');
    const lunch = Math.max(0, Math.min(240, parseInt(r.LunchMin, 10) || 0));
    r.LunchMin = lunch; r.JobNo = '';
    if (o === null) { r.End = ''; r.Hours = 0; }
    else {
      let d = o - i; if (d < 0) d += 1440;
      if (lunch >= d) throw new Error('Lunch is longer than the day');
      r.Hours = Math.round((d - lunch) / 60 * 100) / 100;
    }
    r.Notes = String(r.Notes || '').slice(0, 500);
    return r;
  }
  // break/lunch taken during this entry (minutes) comes off its hours
  const brk = (r.Type === 'Job' || r.Type === 'Shop' || r.Type === 'Travel') ? Math.max(0, Math.min(240, parseInt(r.LunchMin, 10) || 0)) : 0;
  r.LunchMin = brk || '';
  const a = hhmmToMin(r.Start), b = hhmmToMin(r.End);
  if (a !== null && b !== null) {
    let d = b - a; if (d < 0) d += 1440;
    if (brk >= d) throw new Error('Break is longer than the time on this entry');
    r.Hours = (d - brk) / 60;
  } else if (a !== null && b === null && brk >= 0 && (r.Type === 'Job' || r.Type === 'Shop' || r.Type === 'Travel')) {
    // started, not finished yet (tech is entering time as they go)
    r.End = ''; r.Hours = 0;
    r.Notes = String(r.Notes || '').slice(0, 500);
    return r;
  }
  r.Hours = Math.round((parseFloat(r.Hours) || 0) * 100) / 100;
  if (!(r.Hours > 0 && r.Hours <= 24)) throw new Error('Hours must be between 0 and 24');
  r.Notes = String(r.Notes || '').slice(0, 500);
  return r;
}

function techSync(e, ops) {
  const existing = indexBy(rawEntries(), 'EntryID');
  const results = [];
  const upserts = [];
  const deletes = [];
  ops.forEach(op => {
    try {
      const id = op.op === 'delete' ? op.id : (op.entry && op.entry.EntryID);
      const old = existing[id];
      if (old && String(old.EmpID) !== String(e.EmpID)) throw new Error('Not your entry');
      if (old && (old.Status || 'Open') !== 'Open') throw new Error('LOCKED: This entry is ' + old.Status + ' — ask the office to change it');
      if (op.op !== 'delete' && op.entry && op.entry.Type === 'Day') {
        const dup = Object.keys(existing).map(k => existing[k]).filter(x => x && x.Type === 'Day' && String(x.EmpID) === String(e.EmpID) && x.Date === op.entry.Date && x.EntryID !== id)[0];
        if (dup) throw new Error('There is already a day card for ' + op.entry.Date);
      }
      if (op.op === 'delete') {
        if (old) deletes.push(id);
        delete existing[id];
        results.push({ id: id, ok: true, deleted: true });
      } else {
        const r = normalizeEntry(op.entry);
        r.EmpID = e.EmpID;
        r.Employee = e.Name;
        r.Status = 'Open';
        r.OfficeNote = old ? old.OfficeNote : '';
        r.QBExported = old ? qbStamp(old, r) : '';
        r.UpdatedAt = nowStamp();
        r.UpdatedBy = e.Name;
        existing[id] = r;
        upserts.push(r);
        results.push({ id: id, ok: true, entry: cleanEntry(r) });
      }
    } catch (err) {
      const id = op.op === 'delete' ? op.id : (op.entry && op.entry.EntryID);
      const cur = existing[id];
      results.push({ id: id, ok: false, error: String(err.message || err), entry: cur ? cleanEntry(cur) : null });
    }
  });
  // a later op in the same batch may have deleted an upserted row
  const finalUps = upserts.filter(r => existing[r.EntryID] === r);
  Store.upsertMany('Entries', 'EntryID', finalUps);
  if (deletes.length) Store.remove('Entries', 'EntryID', deletes.filter(id => !existing[id]));
  return results;
}
// @@LOGIC_END
