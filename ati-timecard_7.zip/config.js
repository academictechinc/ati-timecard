// ATI Timecard: your server link.
// Paste your Apps Script Web app URL (ends in /exec) between the quotes, then upload this file once.
// Later updates to index.html / admin.html won't touch it.
window.TIMECARD_API_URL = '';
