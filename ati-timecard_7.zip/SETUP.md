# ATI Timecard — Setup Guide

Three pieces:

| File | Who uses it | What it does |
|---|---|---|
| `index.html` (+ `manifest.json`, `sw.js`, icons) | Techs, on their phones | Enter job time, travel, breaks, PTO; submit the week |
| `admin.html` | Accounting, on a PC | Review, approve, send back, track OT, see job hours, export to Excel, print |
| `Code.gs` | Runs inside a Google Sheet | Stores everything. The Sheet is your database, and Google keeps its version history |

`demo-backend.js` is only for trying the apps with sample data. Type **demo** as the server link. On the phone app, the sign-in screen lists the demo PINs. On the dashboard, sign in with name **Demo** and password **demodemo**.

---

## 1. Create the Google Sheet (about 10 minutes)

1. Sign in to a **company** Google account (an admin or payroll account, not a tech's personal account). Create a blank Google Sheet named **ATI Timecard Data**.
2. Go to **Extensions → Apps Script**. Delete the sample code, paste in all of `Code.gs`, and click **Save**.
3. In the function dropdown, choose **setup** and click **Run**. Approve the permission prompt. Google shows an "unverified app" warning because you wrote the script: click **Advanced → Go to project**.
4. Back in the Sheet, open the **Settings** tab and fill in:
   - **AdminPassword**: a *setup-only* password. Change it from `change-me`. It only works until the first office user is created (see step 4).
   - **WeekStart**: your payroll workweek start (0 = Sunday, 1 = Monday). Overtime is calculated over this week.
   - **PayPeriod**: `weekly` or `biweekly`.
   - **PayPeriodAnchor**: the first day of any past pay period, for example `2026-01-04`.
   - **TravelPaid**: `TRUE` if travel time is paid and counts toward OT.
   - **JobSeparator**: the character between customer, PO, and quote in your job numbers (default `-`). Job numbers are the customer abbreviation and PO run together, then the separator and the quote #, e.g. `GHS45021-Q1187`.
5. Click **Deploy → New deployment → ⚙ → Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone** (techs don't need Google accounts; PINs protect the app)
   - Click **Deploy** and copy the **Web app URL** (`https://script.google.com/macros/s/…/exec`).

## 2. Put the URL in the apps

Open `config.js` in Notepad and paste the URL between the quotes:

```js
window.TIMECARD_API_URL = 'https://script.google.com/macros/s/…/exec';
```

Techs and the office then never see a setup screen. Because the link lives in its own file, future updates to `index.html` or `admin.html` won't erase it.

## 3. Host the apps (GitHub Pages, same as your field tools)

1. Create a new repo, for example `ati-timecard`.
2. Upload `config.js`, `index.html`, `admin.html`, `manifest.json`, `admin-manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`, `admin-icon-192.png`, `admin-icon-512.png`, and optionally `demo-backend.js`.
3. Go to **Settings → Pages → Deploy from branch → main / root**.
4. You get these links:
   - Techs: `https://<you>.github.io/ati-timecard/`
   - Office: `https://<you>.github.io/ati-timecard/admin.html`

**Install the office dashboard as an app (PC):** open the office link in **Chrome** or **Edge**, then click the install icon at the right end of the address bar. In Edge you can also use **⋯ → Apps → Install this site as an app**. It gets its own icon on the desktop or Start menu and opens in its own window.

Data never goes to GitHub. It goes straight from the phone to your Google Sheet.

## 4. Create office users, then load employees and jobs

- **Office users first**: open `admin.html`, type your name, and sign in with the AdminPassword. Go to **Employees → Office users → Add office user** and create a login for each person in accounting, yourself included. The setup password stops working the moment the first user exists. Everyone then signs in with their own name and password, and every approval or edit shows who made it.

- **Employees**: in the office dashboard, open **Employees → Add employee**. A PIN is generated and shown **once**. Write it down for the tech. Set **Payroll / QuickBooks name** to match QuickBooks exactly (for example `Hill, Marcus`). Delete the "Test Tech" row from the Sheet.
- **Jobs**: add them in **Job List → Add job**. For a long list, paste rows straight into the **Jobs** tab of the Sheet (JobNo, Customer, PO, Quote, Description, Status = `Active`).
- Give each customer a **full name** as well as its abbreviation, e.g. `MDE` = Mississippi Department of Education. Do it once per abbreviation and every job with that abbreviation picks up the name. Techs and the office can then search by either one, and typing either one suggests the other.
- Set finished jobs to **Closed** so techs' pick lists stay short. Their hours stay in all reports. The **Gone quiet** list at the top of the Job List shows active jobs with no time posted in 30 days (you can change the number), with one-click **Close** buttons. Sort the list by **Last activity** to see stale jobs first.

## 5. Install on tech phones

Text each tech the link and their PIN.

- **iPhone**: open the link in **Safari**, tap Share, then **Add to Home Screen**.
- **Android**: open the link in **Chrome**, tap ⋮, then **Install app** (or **Add to Home screen**).

The app works without signal. Entries show "Not synced" and upload automatically once the phone has a connection again.

---

## Weekly / pay-period workflow

**Techs**
- **Every entry is complete:** job, **time in**, **time out**, and any **break / lunch** (None, 15, 30, 45, 1 hr), which comes off that entry. The day's total is the entries added up.
- **Start of day:** tap **▶ Start day**. It opens a new job entry with time in set to now. They pick the job and save. The job shows as **● Running** until it has a time out.
- **Next job:** tap **+ Job**. Its time in fills in from where the last job ended. If one is still running, the app offers to end it at the new start time.
- **End of day:** tap **■ End day**. It ends whatever's running at the current time.
- **Setting times:** times use big buttons. Time in defaults to AM and time out to PM. **Now** fills in the current time.
- **Day summary:** the dark card at the top shows the first time in, last time out, total breaks, and paid hours. It fills in on its own.
- **Copy my last workday** copies the previous day's entries for long stretches on the same job.
- **New jobs:** if a job isn't listed, they tap **Request a new job number**.
- **End of week:** they tap **Submit week**. It won't submit while a job has no time out.

**Accounting**
1. Open **Payroll**. Paid hours are each tech's entries added up, with breaks taken out.
   - The **Check** column flags: missing days, jobs with no time out, days over 12 hours, no break on a 6+ hour day, unpaid breaks under 30 minutes, and unconfirmed job numbers.
   - The QuickBooks export won't run while any job is still running.
2. Click a tech to see their timesheet. You can edit or add entries, or select entries and use **Send back to tech** with a note. The note shows on the tech's phone and unlocks those entries for them to fix.
3. **Job List**: approve new job requests, or use **Fix / merge…** to correct a typo. All time moves to the corrected number.
4. **Approve all submitted**, then **Export to Excel**. The workbook has these tabs:
   - *Payroll Totals*: regular, OT, PTO, and holiday hours per employee (what you key into payroll)
   - *Payroll by Week*: the same per FLSA workweek
   - *Time Detail*: every line
   - *Job Hours*: job costing by tech
   - *QuickBooks Lines*: the same lines the QuickBooks import file contains, for review
5. **QuickBooks** tab: download the import file (.IIF). See the next section.
6. **Print** gives a payroll summary, with optional per-employee timesheets that have signature lines.

---

## QuickBooks Enterprise import

The **QuickBooks** tab builds an .IIF file for QuickBooks Desktop Enterprise 24 (it also works on Desktop 2022 and later). QuickBooks imports it with **File → Utilities → Import → IIF Files**. The hours land on each employee's weekly timesheet, already split into regular and overtime and tagged with the job and billable status. That means the time also feeds job costing and, if you want, invoicing.

(Intuit removed the old *Import → Timer Activities* menu in Enterprise 22. This file follows Intuit's replacement steps, so it has no Timer header lines and needs no "company create time.")

**One-time setup**
1. On the QuickBooks tab, enter the names of your **service items** (Labor, Travel, Shop) and **payroll items** (regular, overtime, PTO, holiday) exactly as they appear in QuickBooks.
2. In QuickBooks, open each hourly employee's **Payroll Info** and check **"Use time data to create paychecks."**
3. On the **Employees** tab, set each **Payroll / QuickBooks name** to match the Employee Center exactly, e.g. `Hill, Marcus` or `Marcus Hill`, whichever your file uses.
4. On the **Job List**, give each job its **QuickBooks Customer:Job** name, e.g. `Gulfport School District:GHS Press Box`. The export won't run until every job in the period has one, and the QuickBooks tab lists any that are missing so you can fill them in right there.

**Each payroll**
1. Approve the period, either from the Payroll tab or one tech at a time.
2. On the **QuickBooks** tab, check the preview and click **Download .IIF**.
3. In QuickBooks, sign in as **Admin** in **single-user mode** and **back up** the company file.
4. Go to **File → Utilities → Import → IIF Files → Import IIF** and select the file.
5. Check the hours in **Employees → Enter Time → Use Weekly Timesheet**, then create paychecks as usual.

**How overtime is split:** hours over the threshold in each workweek go to the overtime payroll item, starting with the last entries of the week. PTO and holiday hours don't count toward overtime.

**Duplicates:** QuickBooks can't tell when the same time is imported twice. After each download, the dashboard marks those entries as *in QB* and skips them in future exports. If the import fails, use **Undo mark** to export them again. If someone changes an entry after it was sent, it shows **edited after QB** on the Timesheets tab and the QuickBooks tab warns you, so you can fix that one by hand in QuickBooks.

**Try it on a backup first:** do your first import into a copy of the company file to confirm the names match. QuickBooks creates a new employee or item for any name it doesn't recognize.

---

## Maintenance notes

- **After updating `Code.gs`**: run **setup** once more so new columns and settings get added. It never erases data.
- **Updating the backend**: paste the new `Code.gs`, then go to **Deploy → Manage deployments → ✏ → Version: New version → Deploy**. The URL stays the same. (**New deployment** gives you a new URL; don't use it for updates.)
- **Updating the apps**: upload the new HTML to GitHub. The phone app loads fresh whenever it has signal, so there's no cache-busting dance.
- **Forgotten PIN**: click **Reset PIN** on the Employees tab. PINs are stored scrambled, so they can't be looked up. A reset also clears a lockout.
- **Forgotten office password**: another office user can click **Reset password** for them. If *everyone* is locked out, clear the **OfficeUsers** tab in the Sheet. The AdminPassword setup login then works again.
- **Someone leaves**: set them to Inactive. Their history stays.
- **Audit trail**: every entry records who last changed it and when. Google Sheets **File → Version history** shows everything else.
- **Yearly**: when a year closes, copy the Entries tab to an archive spreadsheet and clear the old rows so the app stays fast (it's fine up to roughly 50,000 rows).
- **Security**:
  - **Lockouts**: five wrong PINs locks that tech out for 15 minutes. Five wrong passwords locks that office user out for 15 minutes. Repeated failures across all office names lock dashboard sign-in for everyone for 15 minutes.
  - **Scrambled secrets**: PINs and office passwords are stored as one-way hashes. Anyone who sees the Sheet can't read them back. If you type a PIN straight into the Sheet, it's scrambled the first time that tech signs in.
  - **Sign-in timeouts** (on the **Employees** tab, **Sign-in timeouts** section):
    - **Office dashboard idle timeout**: default 30 minutes, adjustable from 5 to 480. After that much time with no activity, the dashboard signs out.
    - **Tech phone PIN re-entry**: default 30 days. 0 means techs stay signed in until they sign out or the office resets their PIN. Changes apply the next time each tech signs in.
    - Phones and PCs never store the PIN or password, only a sign-in pass that expires. If a tech's pass expires while entries are waiting to sync, those entries are kept and upload after the tech enters the PIN.
    - **Reset PIN** signs out that tech's phone immediately.
    - **Sign everyone out** ends every session on every phone and PC except yours. Use it if a phone is lost or a password may have leaked.
  - **What anyone with the web-app link can do**: see the tech name list that fills the sign-in dropdown. Nothing else works without a PIN or an office password.
  - **Setup**: turn on two-factor sign-in for the Google account that owns the Sheet and script (use a company account, not a personal one), and share the Sheet only with accounting. No SSNs or pay rates are stored, only names and hours.
